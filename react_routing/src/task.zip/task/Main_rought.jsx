import React, { lazy } from 'react'
import { Route, Routes } from 'react-router-dom'
// import Index from './Components/Index'
import Home from './Components/Home'
import About from './Components/About'
import Contect from './Components/Contect'
import Error_404 from './Error'
import Login from './Components/Login'
import Person from './Components/Person'
import { Suspense } from 'react'

function Main_rought() {
  const Index = lazy(()=> import("./Components/Index"))
  const Contect = lazy(()=> import("./Components/Contect"))
  return (
    <Routes>
        <Route path="/" element={<Suspense fallback={<p>it's Loading...</p>}><Index/></Suspense>}>
        <Route path="home" element={<Home/>}/>
        <Route path="about" element={<About/>}/>
        <Route path="contect" element={<Suspense fallback={<p>it's Loading...</p>}><Contect/></Suspense>}/>
        <Route path="person/:id" element={<Person/>}/>
        <Route path="*" element={<Error_404/>}/>
        <Route path="login" element={<Login/>}/>
        </Route>
    </Routes>
  )
}

export default Main_rought